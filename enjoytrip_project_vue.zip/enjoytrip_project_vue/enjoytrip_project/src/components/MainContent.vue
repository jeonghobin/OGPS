<template>
    <div>   <!-- Slide start -->
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active" data-interval="6000">
          <h2 class="carousel-up-text text-center">지금 Enjoy!!Trip 과 함께 우리지역의 관광지를 알아보고<br />나만의 여행 계획을 만들어보세요!!</h2>
          <img src="@/assets/img/top2.1a2c46af.png" class="d-block w-100" alt="..." />
          <div class="carousel-caption d-none d-md-block">
            <h5>신나는 여행 계획 세우고 공유해보세요!</h5>
          </div>
        </div>
        <div class="carousel-item" data-interval="6000">
          <h2 class="carousel-up-text text-center">지금 Enjoy!!Trip 과 함께 우리지역의 관광지를 알아보고<br />나만의 여행 계획을 만들어보세요!!</h2>
          <img src="@/assets/img/top3.31d0592b.png" class="d-block w-100 h-75" alt="..." />

          <div class="carousel-caption d-none d-md-block">
            <h5>신나는 여행 계획 세우고 공유해보세요!</h5>
          </div>
        </div>
        <div class="carousel-item" data-interval="6000">
          <h2 class="carousel-up-text text-center">지금 Enjoy!!Trip 과 함께 우리지역의 관광지를 알아보고<br />나만의 여행 계획을 만들어보세요!!</h2>
          <img src="@/assets/img/top4.297ed701.png" class="d-block w-100" alt="..." />
          <div class="carousel-caption d-none d-md-block">
            <h5>신나는 여행 계획 세우고 공유해보세요!</h5>
          </div>
        </div>
        <div class="carousel-item" data-interval="6000">
          <h2 class="carousel-up-text text-center">지금 Enjoy!!Trip 과 함께 우리지역의 관광지를 알아보고<br />나만의 여행 계획을 만들어보세요!!</h2>
          <img src="@/assets/img/top5.bf00bcca.png" class="d-block w-100" alt="..." />
          <div class="carousel-caption d-none d-md-block">
            <h5>신나는 여행 계획 세우고 공유해보세요!</h5>
          </div>
        </div>
        <div class="carousel-item" data-interval="6000">
          <h2 class="carousel-up-text text-center">지금 Enjoy!!Trip 과 함께 우리지역의 관광지를 알아보고<br />나만의 여행 계획을 만들어보세요!!</h2>
          <img src="@/assets/img/top6.caa86eab.png" class="d-block w-100" alt="..." />
          <div class="carousel-caption d-none d-md-block">
            <h5>신나는 여행 계획 세우고 공유해보세요!</h5>
          </div>
        </div>
        <div class="carousel-item" data-interval="6000">
          <h2 class="carousel-up-text text-center">지금 Enjoy!!Trip 과 함께 우리지역의 관광지를 알아보고<br />나만의 여행 계획을 만들어보세요!!</h2>
          <img src="@/assets/img/top1.6220e4fc.png" class="d-block w-100" alt="..." />
          <div class="carousel-caption d-none d-md-block">
            <h5>신나는 여행 계획 세우고 공유해보세요!</h5>
          </div>
        </div>
      </div>
    </div>
    <!-- Slide end -->

    <!-- 우리지역 관광지 start -->
    <div class="container-fluid pt-3 pb-3 pe-5 ps-5" style="background-color: aliceblue">
      <div class="row">
        <div class="col-md-4 align-self-center">
          <h3 style="font-weight: bold">지역사랑</h3>
          <h2 style="font-weight: bold" class="text-secondary">우리 지역 관광지!</h2>
          <br />
          <h5>우리지역의 숨어있는 아름다운 관광지를 알려드립니다.</h5>
          <h5>관광지 주변의 맛집, 숙박업소와 여행코스, 지역 축제등을 보실수도 있습니다.</h5>
        </div>

        <div class="col-md-8">
          <div class="row pb-3">
            <div class="col">
              <img src="@/assets/img/741661_image2_1.jpg" alt="" class="img-thumbnail" />
              <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <h1 class="main_image_text" style="font-size: 25px"></h1>
              </a>
            </div>
            <div class="col">
              <img src="@/assets/img/1820973_image2_1.jpg" alt="" class="img-thumbnail" />
              <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <h1 class="main_image_text" style="font-size: 25px"></h1>
              </a>
            </div>
            <div class="col">
              <img src="@/assets/img/2659866_image2_1.jpg" alt="" class="img-thumbnail" />
              <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <h1 class="main_image_text" style="font-size: 25px"></h1>
              </a>
            </div>
          </div>

          <div class="row">
            <div class="col">
              <img src="@/assets/img/11098856260173493.jpg" alt="" class="img-thumbnail" />
              <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <h1 class="main_image_text" style="font-size: 25px"></h1>
              </a>
            </div>
            <div class="col">
              <img src="@/assets/img/2841121_image2_1.jpg" alt="" class="img-thumbnail" />
              <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <h1 class="main_image_text" style="font-size: 25px"></h1>
              </a>
            </div>
            <div class="col">
              <img src="@/assets/img/2856653_image2_1.jpg" alt="" class="img-thumbnail" />
              <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <h1 class="main_image_text" style="font-size: 25px"></h1>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 우리지역 관광지 모달창 start -->
    <div class="modal fade modal-xl" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title bi bi-bookmark" id="exampleModalLabel">여행지 이름</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body" style="text-align: center">
            <img class="modalImg" src="@/assets/img/741661_image2_1.jpg" alt="" />
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button>
          </div>
        </div>
      </div>
    </div>
    <!-- 우리지역 관광지 모달창 end -->
    <!-- 우리지역 관광지 end -->

    <!-- 나만의 여행계획!! start -->
    <div class="container" style="margin-top: 30px">
      <div style="text-align: center">
        <h1>나만의 여행계획!!</h1>
        <h3>여행 경로, 숙박, 광광지, 예상금액등 나만의 멋진 계획을 세워 공유해 주세요.</h3>
      </div>
      <div class="d-flex justify-content-center">
        <div class="card" style="width: 18rem; margin: 10px">
          <img src="@/assets/img/map.png" class="card-img-top" alt="..." />
          <div class="card-body">
            <h5 class="card-title">제목</h5>
            <p class="card-text">내용</p>
            <a href="#" class="btn btn-danger">자세히 보기</a>
          </div>
        </div>

        <div class="card" style="width: 18rem; margin: 10px">
          <img src="@/assets/img/map.png" class="card-img-top" alt="..." />
          <div class="card-body">
            <h5 class="card-title">제목</h5>
            <p class="card-text">내용</p>
            <a href="#" class="btn btn-danger">자세히 보기</a>
          </div>
        </div>

        <div class="card" style="width: 18rem; margin: 10px">
          <img src="@/assets/img/map.png" class="card-img-top" alt="..." />
          <div class="card-body">
            <h5 class="card-title">제목</h5>
            <p class="card-text">내용</p>
            <a href="#" class="btn btn-danger">자세히 보기</a>
          </div>
        </div>

        <div class="card" style="width: 18rem; margin: 10px">
          <img src="@/assets/img/map.png" class="card-img-top" alt="..." />
          <div class="card-body">
            <h5 class="card-title">제목</h5>
            <p class="card-text">내용</p>
            <a href="#" class="btn btn-danger">자세히 보기</a>
          </div>
        </div>
      </div>
    </div>
    <!-- 나만의 여행계획!! end -->

    <!-- 핫플 자랑하기 start -->
    <div class="container-fluid pe-5 ps-5" style="margin-top: 30px; padding-top: 20px; padding-bottom: 20px; background-color: aliceblue">
      <div style="text-align: center">
        <h1>핫플 자랑하기</h1>
        <h3>나만 알고있는 핫플!!! 자랑해 주세요!!</h3>
      </div>

      <div class="row mb-1">
        <div class="col">
          <img src="@/assets/img/741661_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
        <div class="col">
          <img src="@/assets/img/1820973_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
        <div class="col">
          <img src="@/assets/img/2659866_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <img src="@/assets/img/741661_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
        <div class="col">
          <img src="@/assets/img/1820973_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
        <div class="col">
          <img src="@/assets/img/2659866_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
      </div>

      <div class="row">
        <div class="col">
          <img src="@/assets/img/741661_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
        <div class="col">
          <img src="@/assets/img/1820973_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
        <div class="col">
          <img src="@/assets/img/2659866_image2_1.jpg" alt="" class="img-thumbnail" />
          <a href="" data-bs-toggle="modal" data-bs-target="#exampleModal">
            <h1 class="main_image_text" style="font-size: 25px">이름</h1>
          </a>
        </div>
      </div>
    </div>
    <!-- 핫플 자랑하기 end -->

    <!-- 사이트 소개 start -->
    <div class="container">
      <div class="col">
        <div class="row" style="margin-top: 10px">
          <img src="@/assets/img/last.png" alt="" />
          <h2 class="last-text">
            언제든 연락주세요.! Enjoy!!! Trip은 여러분의 많은 참여를 기다립니다.
            <br />
            숨어있는 지역 명소와 함께 즐기고 싶은 여행일정이 있다면 언제든지 환영입니다.
            <br />
            02-1234-5678
          </h2>
        </div>
      </div>
    </div>
    </div>

</template>


<script>
export default {
  name: "MainContent",
};
</script>

<style scope>

</style>
